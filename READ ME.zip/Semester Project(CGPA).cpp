#include <iostream>
using namespace std;

int main() {
    int numCourses;
    cout << "Enter the number of courses: ";
    cin >> numCourses;

    int credits[numCourses]; 
    char grades[numCourses];

    for (int i = 0; i < numCourses; i++) {
        cout << "Enter the credit hours for course " << i + 1 << ": ";
        cin >> credits[i];
        cout << "Enter the grade for course " << i + 1 << ": ";
        cin >> grades[i];
    }

    int totalCredits = 0;
    int totalGradePoints = 0;

    for (int i = 0; i < numCourses; i++) {
    	totalGradePoints += grades[i] ;
        totalCredits += credits[i];
         
    }

    double gpa = (totalGradePoints) / totalCredits;

    cout << "Individual grades for each course:"<<endl;
    for (int i = 0; i < numCourses; i++) {
        cout << "Course " << i + 1 << ": " << "Credits: " << credits[i] << ", Grade: " << grades[i] << endl;
    }
    cout<<"Total Credit Hours"<<totalCredits<<endl;
    cout<<"Total Grade Points"<<totalGradePoints<<endl;
    cout << "GPA for the semester: " << gpa << endl;

    return 0;
}
